﻿Public Class Test1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim numberIntFirst As System.Numerics.BigInteger
        Dim result As System.Numerics.BigInteger
        Dim numberInt As System.Numerics.BigInteger
        numberIntFirst = Convert.ToInt64(txtNumber.Text)
        result = numberIntFirst
        numberInt = numberIntFirst - 1

        For i = 1 To numberInt
            result = result * i
        Next
        txtResult.Text = result.ToString()

    End Sub

    Private Sub Test1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub txtNumber_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtNumber.KeyPress
        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtNumber_Leave(sender As System.Object, e As System.EventArgs) Handles txtNumber.Leave
        If txtNumber.Text = Nothing Then
            txtNumber.Text = 1
        End If
        If Convert.ToInt32(txtNumber.Text) > 100 Or txtNumber.Text = 0 Then
            MsgBox("Please only input number from 1 to 100!")
            txtNumber.Text = Nothing
            txtNumber.Focus()
        End If
    End Sub
End Class