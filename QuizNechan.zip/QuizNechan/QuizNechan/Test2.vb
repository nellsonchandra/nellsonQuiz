﻿Public Class Test2
    Dim arr1() As String
    Dim arr2() As Integer
    Dim arrInt1() As Integer
    Dim tempArray() As Integer
    Dim temp As Integer
    Dim problem, solve As Integer
    Dim sorted, isCorrect As Boolean
    Dim isDistinct As Boolean


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        arr1 = txtNumber.Text.Trim.Split(" "c)
        isDistinct = HasDuplicates()
        If arr1.Count = txtSize.Text And isDistinct = False Then
            ReDim arrInt1(arr1.Count - 1)
            ReDim arr2(arr1.Count - 1)
            For i = 0 To arr1.Count - 1
                arrInt1(i) = Convert.ToInt32(arr1(i))
                arr2(i) = arrInt1(i)
            Next
            Array.Sort(arr2)
            isCorrect = checkSorted()
            If isCorrect Then
                txtResult.Text = "No sort is needed !"
            Else
                doSwap()
                If isCorrect = False Then
                    doReverse()
                End If
                If isCorrect = False Then
                    txtResult.Text = "No"
                End If
            End If
        Else
            MsgBox("Size of inputted numbers are not same as array size or there are duplicate numbers !")
        End If
    End Sub

    Private Sub Test2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub

    Function checkSorted()
        For i = 0 To arrInt1.Count - 1
                If (arrInt1(i) = arr2(i)) Then
                    sorted = True
                Else
                    sorted = False
                    problem = i
                    Exit For
                End If
            Next

        Return sorted
    End Function

    Sub refreshArr()
        arr1 = txtNumber.Text.Split(" "c)
        ReDim arrInt1(arr1.Count - 1)
        For i = 0 To arr1.Count - 1
            arrInt1(i) = Convert.ToInt32(arr1(i))
        Next
    End Sub

    Sub doSwap()
        For i = problem To arrInt1.Count
            isCorrect = checkSorted()
            If isCorrect = False Then
                refreshArr()
                temp = arrInt1(problem)
                If i <> arrInt1.Count Then
                    arrInt1(problem) = arrInt1(i)
                    arrInt1(i) = temp
                End If

            Else
                'MsgBox(arrInt1(i))
                txtResult.Text = "Swapped " & problem + 1 & " and " & i
                Exit For
            End If
        Next
    End Sub

    Sub doReverse()
        Dim test As String
        For i = arrInt1.Count To problem Step -1
            isCorrect = checkSorted()
            If isCorrect = False Then
                refreshArr()
                'ReDim tempArray(arrInt1.Count - (problem + 1))
                ReDim tempArray(i - (problem + 1))
                For j = 0 To tempArray.Count - 1
                    tempArray(j) = arrInt1(problem + j)

                Next
                Array.Reverse(tempArray)
                For j = 0 To tempArray.Count - 1
                    arrInt1(problem + j) = tempArray(j)
                    solve = j + problem
                Next
            Else
                txtResult.Text = "Reversed from " & problem + 1 & " to " & solve + 1
                Exit For
            End If
        Next
    End Sub

    Private Sub txtSize_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtSize.KeyPress
        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtNumber_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtNumber.KeyPress

        If Asc(e.KeyChar) <> 8 Then
            If (Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57) And Asc(e.KeyChar) <> 32 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Function HasDuplicates() As Boolean
        For i As Integer = 0 To arr1.Count - 1
            If Not arr1(i) Is Nothing Then
                Dim l As Integer = Array.LastIndexOf(arr1, arr1(i))
                If l <> i Then Return True
            End If
        Next
        Return False
    End Function

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class