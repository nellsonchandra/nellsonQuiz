﻿Public Class Test3
    Dim arr(,) As Integer
    Dim arr1() As String
    Dim m, n, r, c As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtResult.Text = ""
        arr1 = txtInput.Text.Trim.Split(" "c)
        m = arr1(0)
        n = arr1(1)
        r = arr1(2)
        If (m >= 2 And m <= 300) And (n >= 2 And m <= 300) And (r >= 1 And r <= 109) And ((m Mod 2) = 0 Or (n Mod 2) = 0) Then
            ReDim arr(m, n)
            c = 1
            Try
                For i = 0 To n - 1
                    For j = 0 To m - 1
                        arr(j, i) = c
                        c += 1
                    Next
                Next

                RotateArr()
                DisplayArr()

            Catch ex As Exception
                MessageBox.Show(ex.ToString)
            End Try
        Else
            MsgBox("Something is wrong with your input, please try again !")
        End If
    End Sub

    Sub RotateArr()
        Dim AreaCount As Integer
        Dim x, y, turun, side, count As Integer
        Dim way As String = ""
        Dim temp, oldtemp As Integer
        AreaCount = CInt(Math.Min(m, n) / 2)
        Try
            For i = 0 To r - 1
                For j = 0 To AreaCount - 1
                    x = j
                    y = j
                    turun = n - (j * 2)
                    side = m - (j * 2)
                    way = "DOWN"
                    oldtemp = arr(x, y)
                    count = 1
                    For k = 0 To ((2 * turun) + (2 * side)) - 5
                        temp = oldtemp
                        If way = "DOWN" Then
                            y = y + 1
                            count += 1
                            oldtemp = arr(x, y)
                            arr(x, y) = temp
                            If count = turun Then
                                way = "RIGHT"
                                count = 1
                            End If
                        ElseIf way = "RIGHT" Then
                            x = x + 1
                            count += 1
                            oldtemp = arr(x, y)
                            arr(x, y) = temp
                            If count = side Then
                                way = "UP"
                                count = turun
                            End If
                        ElseIf way = "UP" Then
                            y = y - 1
                            count -= 1
                            oldtemp = arr(x, y)
                            arr(x, y) = temp
                            If count = 1 Then
                                way = "LEFT"
                                count = side
                            End If
                        ElseIf way = "LEFT" Then
                            x = x - 1
                            count -= 1
                            oldtemp = arr(x, y)
                            arr(x, y) = temp
                            If count = 1 Then
                                way = "DOWN"
                                count = 1
                            End If
                        End If

                    Next
                Next
            Next

        Catch ex As Exception
            MessageBox.Show(side.ToString + "<-SIDE DOWN->" + turun.ToString)
            MessageBox.Show(x.ToString + "<-X Y->" + y.ToString)
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Sub DisplayArr()
        For i = 0 To n - 1
            For j = 0 To m - 1
                txtResult.Text = txtResult.Text + arr(j, i).ToString + vbTab
            Next
            txtResult.Text = txtResult.Text + vbCrLf
        Next
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub txtInput_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtInput.KeyPress
        If Asc(e.KeyChar) <> 8 Then
            If (Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57) And Asc(e.KeyChar) <> 32 Then
                e.Handled = True
            End If
        End If
    End Sub
End Class